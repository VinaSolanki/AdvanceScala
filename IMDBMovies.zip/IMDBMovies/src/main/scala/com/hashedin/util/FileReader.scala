package com.hashedin.util

import com.hashedin.bean.Movies
import java.io.{File, FileNotFoundException}
import scala.collection.mutable.ListBuffer
import scala.io.Source


class FileReader {
   def fileContainReading(fileName: String): ListBuffer[Movies] = {
    var moviesDetails = new ListBuffer[Movies]()
    try {
      val fileSource = Source.fromFile(fileName)
      for (line <- fileSource.getLines.drop(1)) {
        val row = line.split("\t").map(_.trim)
        try {
          moviesDetails += new Movies(row(0),row(1), row(2), row(3).toInt, row(4), row(5), row(6).toInt, row(7), row(8), row(9)
            , row(10), row(11), row(12), row(13),
            if(row.size>=15) row(14).toDouble else 0,
            if(row.size>=16) row(15).toInt else 0,
            if(row.size>=17) row(16) else 0,
            if(row.size>=18) row(17) else 0,
            if(row.size>=19) row(18) else 0,
            if(row.size>=20) row(19) else ""
            , if(row.size>=21 && !row(20).isBlank) row(20).toInt else 0,
            if(row.size>=22 && !row(20).isBlank ) row(21).toInt else 0)
        } catch {
          case e: NumberFormatException => {
            println(e.printStackTrace())
          }
          case f: Exception => {
            println(f)
          }
        }

      }
      fileSource.close()
    } catch {
      case _: FileNotFoundException =>
        throw new FileNotFoundException()
    }
    moviesDetails
  }
}
